

export let initialMemberValues = { 
    fname: '',
    mname: '',
    lname: '',
    address: '',
    profile_picture_url: '',
    mobile: '',
    email: '',
    status: '',
    city: ''
}