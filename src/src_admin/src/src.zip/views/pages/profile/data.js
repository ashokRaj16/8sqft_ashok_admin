
export const initialProfileValues = {
    fname: "",
    mname: '',
    lname: '',
    email: '',
    mobile : '',
    address: "",
    education: "",
    aadhaar: "",
    pan: "",
};

export const initialPasswordValues = {
    oldPassword: "",
    newPassword: "",
    confirmPassword: "",
};