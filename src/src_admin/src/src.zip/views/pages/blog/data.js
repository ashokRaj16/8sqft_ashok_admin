
export let initialBlogValues = { 
    title: '',
    description: '',
    short_description: '',
    author_name: '',
    category : '',
    tags : '',
    meta_title: '',
    meta_description: '',
    meta_keyword: '',
    comment_enabled: '',
    canonical_url: '',
    banner_image: '',
    banner_video : '',
    publish_date  :'',
}



//   const initialValues = {
//     title: "",
//     blogImage: null,
//     category: "",
//     tags: "",
//     commentEnabled: false,
//     author: "",
//     publishDate: "",
//     content: "",
//     metaTitle: "",
//     metaDescription: "",
//     metaKeywords: "",
//     canonicalUrl: "",
//   };