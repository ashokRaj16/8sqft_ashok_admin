
const EditAdminUser = (props) => {
    return (
        <div>
            <h1>Users</h1>
        </div>
    )
}

export default EditAdminUser;