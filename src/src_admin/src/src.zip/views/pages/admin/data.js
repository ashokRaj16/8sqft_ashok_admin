
export let initialAdminValues = { 
    fname: '',
    mname: '',
    lname: '',
    address: '',
    profile_picture_url: '',
    mobile: '',
    email: '',
    status: '',
    city: '',
    role: '',
    password: '',
    cpassword: ''
}